woman(mia).
woman(jody).
woman(yolanda).
playsAirGuitar(jody).
party.