# AI-Lab

Assignment 6 - Animal Habitat expert system
